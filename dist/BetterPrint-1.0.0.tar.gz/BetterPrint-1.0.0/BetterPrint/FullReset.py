import colorama
from colorama import Style

def FullReset():
    print(Style.RESET_ALL)