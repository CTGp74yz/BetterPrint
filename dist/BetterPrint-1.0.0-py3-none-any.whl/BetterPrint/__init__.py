from FullReset import FullReset
from BetterPrint import BetterPrint
from SplitPrint import SingleWord
from InputPrint import InputPrint