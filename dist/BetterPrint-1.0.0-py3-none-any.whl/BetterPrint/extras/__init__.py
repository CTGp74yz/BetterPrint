from SplitPrint import SingleWord
from InputPrint import InputPrint